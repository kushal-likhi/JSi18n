

ant.mkdir(dir:"${basedir}/web-app/js/jsi18n")
ant.mkdir(dir:"${basedir}/web-app/js/jsi18n/generated")

