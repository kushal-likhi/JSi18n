package org.devunited.grails.plugin.jsi18n


class DescriptorHelper {

    static def doWithWebDescriptor = { xml ->
    }

    static def doWithSpring = {
    }

    static def doWithDynamicMethods = { ctx ->
    }

    static def doWithApplicationContext = Loader.buildAll

    static def onChange = Loader.buildAll

    static def onConfigChange = { event ->
    }

    static def onShutdown = { event ->
    }
}
